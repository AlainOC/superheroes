import PouStyleGame from "../pou-style-game"

export default function Page() {
  return <PouStyleGame />
}
