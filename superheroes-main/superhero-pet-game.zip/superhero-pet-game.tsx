"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Heart, Smile, Coins, ShoppingCart, Plus, Gamepad2, Droplets, Utensils } from "lucide-react"

interface Hero {
  id: string
  name: string
  power: string
  color: string
}

interface Pet {
  id: string
  name: string
  type: string
  heroId: string
  health: number
  happiness: number
  hunger: number
  cleanliness: number
  illness?: string
  accessories: string[]
  lastFed: number
  lastPlayed: number
  lastBathed: number
}

interface Item {
  id: string
  name: string
  type: "food" | "toy" | "accessory" | "medicine"
  price: number
  effect: {
    health?: number
    happiness?: number
    hunger?: number
    cleanliness?: number
  }
  icon: string
}

const defaultHeroes: Hero[] = [
  { id: "1", name: "Thunder Strike", power: "Lightning Control", color: "bg-yellow-500" },
  { id: "2", name: "Fire Phoenix", power: "Fire Manipulation", color: "bg-red-500" },
  { id: "3", name: "Ice Guardian", power: "Ice Powers", color: "bg-blue-500" },
  { id: "4", name: "Nature Spirit", power: "Plant Control", color: "bg-green-500" },
]

const defaultPets: Pet[] = [
  {
    id: "1",
    name: "Sparky",
    type: "Electric Dragon",
    heroId: "1",
    health: 80,
    happiness: 70,
    hunger: 60,
    cleanliness: 90,
    accessories: [],
    lastFed: Date.now() - 3600000,
    lastPlayed: Date.now() - 1800000,
    lastBathed: Date.now() - 7200000,
  },
  {
    id: "2",
    name: "Blaze",
    type: "Fire Wolf",
    heroId: "2",
    health: 90,
    happiness: 85,
    hunger: 40,
    cleanliness: 70,
    accessories: [],
    lastFed: Date.now() - 1800000,
    lastPlayed: Date.now() - 900000,
    lastBathed: Date.now() - 5400000,
  },
]

const shopItems: Item[] = [
  { id: "1", name: "Super Food", type: "food", price: 10, effect: { hunger: 30, health: 5 }, icon: "🍖" },
  { id: "2", name: "Energy Drink", type: "food", price: 15, effect: { hunger: 20, happiness: 10 }, icon: "🥤" },
  { id: "3", name: "Laser Toy", type: "toy", price: 25, effect: { happiness: 25 }, icon: "🔴" },
  { id: "4", name: "Flying Ball", type: "toy", price: 20, effect: { happiness: 20 }, icon: "⚽" },
  { id: "5", name: "Hero Cape", type: "accessory", price: 50, effect: { happiness: 15 }, icon: "🦸" },
  { id: "6", name: "Power Collar", type: "accessory", price: 75, effect: { health: 10, happiness: 10 }, icon: "⭐" },
  { id: "7", name: "Health Potion", type: "medicine", price: 30, effect: { health: 40 }, icon: "🧪" },
  { id: "8", name: "Happy Pills", type: "medicine", price: 25, effect: { happiness: 35 }, icon: "💊" },
]

const illnesses = ["Cold", "Tired", "Sad", "Hungry", "Dirty"]

export default function SuperheroPetGame() {
  const [heroes, setHeroes] = useState<Hero[]>(defaultHeroes)
  const [pets, setPets] = useState<Pet[]>(defaultPets)
  const [selectedHero, setSelectedHero] = useState<Hero | null>(null)
  const [selectedPet, setSelectedPet] = useState<Pet | null>(null)
  const [coins, setCoins] = useState(100)
  const [inventory, setInventory] = useState<{ [key: string]: number }>({})
  const [newHeroName, setNewHeroName] = useState("")
  const [newHeroPower, setNewHeroPower] = useState("")
  const [newPetName, setNewPetName] = useState("")
  const [newPetType, setNewPetType] = useState("")

  // Simulación del paso del tiempo
  useEffect(() => {
    const interval = setInterval(() => {
      setPets((prevPets) =>
        prevPets.map((pet) => {
          const now = Date.now()
          const newPet = { ...pet }

          // Decrementar stats con el tiempo
          if (now - pet.lastFed > 3600000) {
            // 1 hora
            newPet.hunger = Math.max(0, pet.hunger - 1)
            newPet.health = Math.max(0, pet.health - 0.5)
          }

          if (now - pet.lastPlayed > 1800000) {
            // 30 minutos
            newPet.happiness = Math.max(0, pet.happiness - 1)
          }

          if (now - pet.lastBathed > 7200000) {
            // 2 horas
            newPet.cleanliness = Math.max(0, pet.cleanliness - 1)
          }

          // Posibilidad de enfermarse
          if (Math.random() < 0.001 && !newPet.illness) {
            if (newPet.health < 30 || newPet.happiness < 20 || newPet.cleanliness < 30) {
              newPet.illness = illnesses[Math.floor(Math.random() * illnesses.length)]
            }
          }

          return newPet
        }),
      )
    }, 5000) // Actualizar cada 5 segundos

    return () => clearInterval(interval)
  }, [])

  const createHero = () => {
    if (newHeroName && newHeroPower) {
      const newHero: Hero = {
        id: Date.now().toString(),
        name: newHeroName,
        power: newHeroPower,
        color: `bg-${["purple", "pink", "indigo", "teal", "orange"][Math.floor(Math.random() * 5)]}-500`,
      }
      setHeroes([...heroes, newHero])
      setNewHeroName("")
      setNewHeroPower("")
    }
  }

  const createPet = () => {
    if (newPetName && newPetType && selectedHero) {
      const newPet: Pet = {
        id: Date.now().toString(),
        name: newPetName,
        type: newPetType,
        heroId: selectedHero.id,
        health: 100,
        happiness: 100,
        hunger: 100,
        cleanliness: 100,
        accessories: [],
        lastFed: Date.now(),
        lastPlayed: Date.now(),
        lastBathed: Date.now(),
      }
      setPets([...pets, newPet])
      setNewPetName("")
      setNewPetType("")
    }
  }

  const feedPet = () => {
    if (selectedPet) {
      setPets(
        pets.map((pet) =>
          pet.id === selectedPet.id
            ? {
                ...pet,
                hunger: Math.min(100, pet.hunger + 20),
                health: Math.min(100, pet.health + 5),
                lastFed: Date.now(),
              }
            : pet,
        ),
      )
      setCoins(coins + 5)
      setSelectedPet((prev) =>
        prev ? { ...prev, hunger: Math.min(100, prev.hunger + 20), health: Math.min(100, prev.health + 5) } : null,
      )
    }
  }

  const playWithPet = () => {
    if (selectedPet) {
      setPets(
        pets.map((pet) =>
          pet.id === selectedPet.id
            ? { ...pet, happiness: Math.min(100, pet.happiness + 25), lastPlayed: Date.now() }
            : pet,
        ),
      )
      setCoins(coins + 8)
      setSelectedPet((prev) => (prev ? { ...prev, happiness: Math.min(100, prev.happiness + 25) } : null))
    }
  }

  const bathePet = () => {
    if (selectedPet) {
      setPets(
        pets.map((pet) =>
          pet.id === selectedPet.id
            ? {
                ...pet,
                cleanliness: Math.min(100, pet.cleanliness + 30),
                happiness: Math.min(100, pet.happiness + 10),
                lastBathed: Date.now(),
              }
            : pet,
        ),
      )
      setCoins(coins + 6)
      setSelectedPet((prev) =>
        prev
          ? {
              ...prev,
              cleanliness: Math.min(100, prev.cleanliness + 30),
              happiness: Math.min(100, prev.happiness + 10),
            }
          : null,
      )
    }
  }

  const buyItem = (item: Item) => {
    if (coins >= item.price) {
      setCoins(coins - item.price)
      setInventory((prev) => ({ ...prev, [item.id]: (prev[item.id] || 0) + 1 }))
    }
  }

  const useItem = (item: Item) => {
    if (selectedPet && inventory[item.id] > 0) {
      setPets(
        pets.map((pet) => {
          if (pet.id === selectedPet.id) {
            const updatedPet = { ...pet }
            if (item.effect.health) updatedPet.health = Math.min(100, pet.health + item.effect.health)
            if (item.effect.happiness) updatedPet.happiness = Math.min(100, pet.happiness + item.effect.happiness)
            if (item.effect.hunger) updatedPet.hunger = Math.min(100, pet.hunger + item.effect.hunger)
            if (item.effect.cleanliness)
              updatedPet.cleanliness = Math.min(100, pet.cleanliness + item.effect.cleanliness)

            if (item.type === "medicine") {
              updatedPet.illness = undefined
            }

            if (item.type === "accessory" && !pet.accessories.includes(item.id)) {
              updatedPet.accessories = [...pet.accessories, item.id]
            }

            return updatedPet
          }
          return pet
        }),
      )

      setInventory((prev) => ({ ...prev, [item.id]: prev[item.id] - 1 }))
    }
  }

  const getHealthColor = (value: number) => {
    if (value > 70) return "bg-green-500"
    if (value > 40) return "bg-yellow-500"
    return "bg-red-500"
  }

  const getHappinessColor = (value: number) => {
    if (value > 70) return "bg-blue-500"
    if (value > 40) return "bg-orange-500"
    return "bg-gray-500"
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-400 via-pink-500 to-red-500 p-4">
      <div className="max-w-6xl mx-auto">
        <h1 className="text-4xl font-bold text-white text-center mb-8">🦸 Superhero Pet Game 🐾</h1>

        <div className="flex justify-between items-center mb-6">
          <div className="flex items-center gap-2 bg-white/20 backdrop-blur-sm rounded-lg px-4 py-2">
            <Coins className="text-yellow-400" />
            <span className="text-white font-bold">{coins} Coins</span>
          </div>
        </div>

        <Tabs defaultValue="heroes" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="heroes">Heroes</TabsTrigger>
            <TabsTrigger value="pets">Pets</TabsTrigger>
            <TabsTrigger value="care">Pet Care</TabsTrigger>
            <TabsTrigger value="shop">Shop</TabsTrigger>
          </TabsList>

          <TabsContent value="heroes" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {heroes.map((hero) => (
                <Card
                  key={hero.id}
                  className={`cursor-pointer transition-all hover:scale-105 ${selectedHero?.id === hero.id ? "ring-4 ring-white" : ""}`}
                  onClick={() => setSelectedHero(hero)}
                >
                  <CardHeader>
                    <div
                      className={`w-16 h-16 ${hero.color} rounded-full mx-auto mb-2 flex items-center justify-center text-2xl`}
                    >
                      🦸
                    </div>
                    <CardTitle className="text-center">{hero.name}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-center text-sm text-muted-foreground">{hero.power}</p>
                  </CardContent>
                </Card>
              ))}
            </div>

            <Dialog>
              <DialogTrigger asChild>
                <Button className="w-full">
                  <Plus className="mr-2" />
                  Create New Hero
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Create New Hero</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  <Input placeholder="Hero Name" value={newHeroName} onChange={(e) => setNewHeroName(e.target.value)} />
                  <Input
                    placeholder="Super Power"
                    value={newHeroPower}
                    onChange={(e) => setNewHeroPower(e.target.value)}
                  />
                  <Button onClick={createHero} className="w-full">
                    Create Hero
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </TabsContent>

          <TabsContent value="pets" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {pets
                .filter((pet) => (selectedHero ? pet.heroId === selectedHero.id : true))
                .map((pet) => (
                  <Card
                    key={pet.id}
                    className={`cursor-pointer transition-all hover:scale-105 ${selectedPet?.id === pet.id ? "ring-4 ring-white" : ""}`}
                    onClick={() => setSelectedPet(pet)}
                  >
                    <CardHeader>
                      <div className="w-16 h-16 bg-gradient-to-br from-blue-400 to-purple-500 rounded-full mx-auto mb-2 flex items-center justify-center text-2xl">
                        🐾
                      </div>
                      <CardTitle className="text-center">{pet.name}</CardTitle>
                      {pet.illness && (
                        <Badge variant="destructive" className="mx-auto">
                          Sick: {pet.illness}
                        </Badge>
                      )}
                    </CardHeader>
                    <CardContent>
                      <p className="text-center text-sm text-muted-foreground mb-2">{pet.type}</p>
                      <div className="space-y-2">
                        <div className="flex items-center gap-2">
                          <Heart className="w-4 h-4 text-red-500" />
                          <Progress value={pet.health} className="flex-1" />
                          <span className="text-xs">{Math.round(pet.health)}%</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Smile className="w-4 h-4 text-blue-500" />
                          <Progress value={pet.happiness} className="flex-1" />
                          <span className="text-xs">{Math.round(pet.happiness)}%</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
            </div>

            {selectedHero && (
              <Dialog>
                <DialogTrigger asChild>
                  <Button className="w-full">
                    <Plus className="mr-2" />
                    Create New Pet for {selectedHero.name}
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Create New Pet</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4">
                    <Input placeholder="Pet Name" value={newPetName} onChange={(e) => setNewPetName(e.target.value)} />
                    <Input
                      placeholder="Pet Type (e.g., Fire Cat, Ice Bird)"
                      value={newPetType}
                      onChange={(e) => setNewPetType(e.target.value)}
                    />
                    <Button onClick={createPet} className="w-full">
                      Create Pet
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>
            )}
          </TabsContent>

          <TabsContent value="care" className="space-y-4">
            {selectedPet ? (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      🐾 {selectedPet.name}
                      {selectedPet.illness && <Badge variant="destructive">Sick: {selectedPet.illness}</Badge>}
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-3">
                      <div className="flex items-center gap-2">
                        <Heart className="w-5 h-5 text-red-500" />
                        <span className="w-16 text-sm">Health:</span>
                        <Progress
                          value={selectedPet.health}
                          className={`flex-1 ${getHealthColor(selectedPet.health)}`}
                        />
                        <span className="text-sm font-bold">{Math.round(selectedPet.health)}%</span>
                      </div>

                      <div className="flex items-center gap-2">
                        <Smile className="w-5 h-5 text-blue-500" />
                        <span className="w-16 text-sm">Happy:</span>
                        <Progress
                          value={selectedPet.happiness}
                          className={`flex-1 ${getHappinessColor(selectedPet.happiness)}`}
                        />
                        <span className="text-sm font-bold">{Math.round(selectedPet.happiness)}%</span>
                      </div>

                      <div className="flex items-center gap-2">
                        <Utensils className="w-5 h-5 text-green-500" />
                        <span className="w-16 text-sm">Hunger:</span>
                        <Progress value={selectedPet.hunger} className="flex-1" />
                        <span className="text-sm font-bold">{Math.round(selectedPet.hunger)}%</span>
                      </div>

                      <div className="flex items-center gap-2">
                        <Droplets className="w-5 h-5 text-cyan-500" />
                        <span className="w-16 text-sm">Clean:</span>
                        <Progress value={selectedPet.cleanliness} className="flex-1" />
                        <span className="text-sm font-bold">{Math.round(selectedPet.cleanliness)}%</span>
                      </div>
                    </div>

                    {selectedPet.accessories.length > 0 && (
                      <div>
                        <h4 className="font-semibold mb-2">Accessories:</h4>
                        <div className="flex flex-wrap gap-2">
                          {selectedPet.accessories.map((accessoryId) => {
                            const accessory = shopItems.find((item) => item.id === accessoryId)
                            return accessory ? (
                              <Badge key={accessoryId} variant="secondary">
                                {accessory.icon} {accessory.name}
                              </Badge>
                            ) : null
                          })}
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Pet Activities</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <Button onClick={feedPet} className="w-full bg-transparent" variant="outline">
                      <Utensils className="mr-2" />
                      Feed Pet (+5 coins)
                    </Button>
                    <Button onClick={playWithPet} className="w-full bg-transparent" variant="outline">
                      <Gamepad2 className="mr-2" />
                      Play with Pet (+8 coins)
                    </Button>
                    <Button onClick={bathePet} className="w-full bg-transparent" variant="outline">
                      <Droplets className="mr-2" />
                      Bathe Pet (+6 coins)
                    </Button>
                  </CardContent>
                </Card>
              </div>
            ) : (
              <Card>
                <CardContent className="text-center py-8">
                  <p className="text-muted-foreground">Select a pet to start caring for it!</p>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="shop" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {shopItems.map((item) => (
                <Card key={item.id}>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <span className="text-2xl">{item.icon}</span>
                      {item.name}
                    </CardTitle>
                    <Badge
                      variant={
                        item.type === "food"
                          ? "default"
                          : item.type === "toy"
                            ? "secondary"
                            : item.type === "accessory"
                              ? "outline"
                              : "destructive"
                      }
                    >
                      {item.type}
                    </Badge>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="font-bold text-lg">{item.price} coins</span>
                      {inventory[item.id] > 0 && <Badge variant="secondary">Own: {inventory[item.id]}</Badge>}
                    </div>

                    <div className="text-sm text-muted-foreground">
                      Effects:
                      {item.effect.health && <div>+{item.effect.health} Health</div>}
                      {item.effect.happiness && <div>+{item.effect.happiness} Happiness</div>}
                      {item.effect.hunger && <div>+{item.effect.hunger} Hunger</div>}
                      {item.effect.cleanliness && <div>+{item.effect.cleanliness} Cleanliness</div>}
                    </div>

                    <div className="flex gap-2">
                      <Button onClick={() => buyItem(item)} disabled={coins < item.price} className="flex-1">
                        <ShoppingCart className="mr-2 w-4 h-4" />
                        Buy
                      </Button>

                      {inventory[item.id] > 0 && (
                        <Button onClick={() => useItem(item)} variant="outline" className="flex-1">
                          Use
                        </Button>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
